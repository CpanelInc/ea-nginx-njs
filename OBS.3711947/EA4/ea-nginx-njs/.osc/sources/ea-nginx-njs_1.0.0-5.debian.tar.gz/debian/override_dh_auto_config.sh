#!/bin/bash

source debian/vars.sh

# You will be in ./nginx-build after this source()
#    so that configure and make etc can happen.
# We probably want to popd back when we are done in there
. /opt/cpanel/ea-nginx-ngxdev/set_NGINX_CONFIGURE_array.sh
./auto/configure "${NGINX_CONFIGURE[@]}" --add-dynamic-module=../nginx/
make 
popd

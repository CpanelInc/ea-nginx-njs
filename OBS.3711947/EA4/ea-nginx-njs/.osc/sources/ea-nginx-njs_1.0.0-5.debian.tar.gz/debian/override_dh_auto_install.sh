#!/bin/bash

source debian/vars.sh

mkdir -p $buildroot/etc/nginx/conf.d/modules
install $SOURCE1 $buildroot/etc/nginx/conf.d/modules/ngx_njs_module.conf
mkdir -p $buildroot$_libdir/nginx/modules
install ./nginx-build/objs/ngx_stream_js_module.so $buildroot$_libdir/nginx/modules/ngx_stream_js_module.so
install ./nginx-build/objs/ngx_http_js_module.so $buildroot$_libdir/nginx/modules/ngx_http_js_module.so

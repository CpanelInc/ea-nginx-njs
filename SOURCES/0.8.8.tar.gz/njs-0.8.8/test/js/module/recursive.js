import _ from 'recursive.js';
export default 42;

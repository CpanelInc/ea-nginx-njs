function f() {
    return globalThis.a;
}

export default {f};

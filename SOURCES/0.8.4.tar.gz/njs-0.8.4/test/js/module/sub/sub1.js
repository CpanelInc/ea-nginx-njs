function hash() {
    return sub2.hash();
}

function error() {
    return {}.a.a;
}

import sub2 from 'sub2.js';

export default {hash, error};

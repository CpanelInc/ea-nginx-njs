/*---
includes: []
flags: []
paths: [test/js/module/]
---*/

import imp from 'lib4.js';

assert.sameValue(imp, 10);

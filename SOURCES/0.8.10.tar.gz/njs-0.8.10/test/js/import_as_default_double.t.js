/*---
includes: []
flags: []
paths: [test/js/module]
negative:
  phase: runtime
---*/

import m from 'lib5.js';

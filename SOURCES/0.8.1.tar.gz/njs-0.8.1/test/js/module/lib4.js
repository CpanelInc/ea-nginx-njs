var var10 = 10;
export { var10 as default };

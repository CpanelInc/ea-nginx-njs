var obj = {
  a:1,
  b:2
}

export default obj;

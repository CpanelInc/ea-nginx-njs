
/*
 * Copyright (C) Dmitry Volyntsev
 * Copyright (C) F5, Inc.
 */

#include <qjs.h>
#include <njs_sprintf.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/c14n.h>
#include <libxml/xpathInternals.h>


typedef struct qjs_xml_retired_s  qjs_xml_retired_t;

struct qjs_xml_retired_s {
    xmlNode            *nodes;
    qjs_xml_retired_t  *next;
};


typedef struct {
    xmlDoc             *doc;
    qjs_xml_retired_t  *retired;
    int                ref_count;
} qjs_xml_doc_t;


typedef struct {
    xmlNode        *node;
    qjs_xml_doc_t  *doc;
} qjs_xml_node_t;


typedef struct {
    xmlNode        *node;
    qjs_xml_doc_t  *doc;
} qjs_xml_attr_t;


typedef enum {
    XML_NSET_TREE = 0,
    XML_NSET_TREE_NO_COMMENTS,
    XML_NSET_TREE_INVERT,
} qjs_xml_nset_type_t;


typedef struct qjs_xml_nset_s  qjs_xml_nset_t;

struct qjs_xml_nset_s {
    xmlNodeSet           *nodes;
    xmlDoc               *doc;
    qjs_xml_nset_type_t  type;
    qjs_xml_nset_t       *next;
    qjs_xml_nset_t       *prev;
};


static JSValue qjs_xml_parse(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv);
static JSValue qjs_xml_canonicalization(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv, int magic);

static int qjs_xml_doc_get_own_property(JSContext *cx,
    JSPropertyDescriptor *pdesc, JSValueConst obj, JSAtom prop);
static int qjs_xml_doc_get_own_property_names(JSContext *cx,
    JSPropertyEnum **ptab, uint32_t *plen, JSValueConst obj);
static void qjs_xml_doc_finalizer(JSRuntime *rt, JSValue val);
static void qjs_xml_doc_free(JSRuntime *rt, qjs_xml_doc_t *current);

static JSValue qjs_xml_node_make(JSContext *cx, qjs_xml_doc_t *doc,
    xmlNode *node);
static int qjs_xml_node_has_method(JSContext *cx, JSValueConst obj,
    JSAtom prop, njs_str_t *name);
static JSValue qjs_xml_attr_value(JSContext *cx, xmlAttr *attr);
static int qjs_xml_node_get_own_property(JSContext *cx,
    JSPropertyDescriptor *pdesc, JSValueConst obj, JSAtom prop);
static int qjs_xml_node_get_own_property_names(JSContext *cx,
    JSPropertyEnum **ptab, uint32_t *plen, JSValueConst obj);
static int qjs_xml_node_set_property(JSContext *cx, JSValueConst obj,
    JSAtom atom, JSValueConst value, JSValueConst receiver, int flags);
static int qjs_xml_node_delete_property(JSContext *cx, JSValueConst obj,
    JSAtom prop);
static int qjs_xml_node_define_own_property(JSContext *cx, JSValueConst obj,
    JSAtom atom, JSValueConst value, JSValueConst getter, JSValueConst setter,
    int flags);
static int qjs_xml_node_property_modify(JSContext *cx, JSValueConst obj,
    JSAtom atom, JSValueConst value, int delete);
static JSValue qjs_xml_node_add_child(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv);
static JSValue qjs_xml_node_get_attribute_ns(JSContext *cx,
    JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue qjs_xml_node_get_child_ns(JSContext *cx,
    JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue qjs_xml_node_remove_children(JSContext *cx,
    JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue qjs_xml_node_set_attribute(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv);
static JSValue qjs_xml_node_remove_attribute(JSContext *cx,
    JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue qjs_xml_node_remove_all_attributes(JSContext *cx,
    JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue qjs_xml_node_set_text(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv);
static JSValue qjs_xml_node_remove_text(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv);
static void qjs_xml_node_finalizer(JSRuntime *rt, JSValue val);
static xmlNode *qjs_xml_node(JSContext *cx, JSValueConst val, xmlDoc **doc);

static JSValue qjs_xml_attr_make(JSContext *cx, qjs_xml_doc_t *doc,
    xmlNode *node);
static int qjs_xml_attr_get_own_property(JSContext *cx,
    JSPropertyDescriptor *pdesc, JSValueConst obj, JSAtom prop);
static int qjs_xml_attr_get_own_property_names(JSContext *cx,
    JSPropertyEnum **ptab, uint32_t *plen, JSValueConst obj);
static void qjs_xml_attr_finalizer(JSRuntime *rt, JSValue val);

static u_char **qjs_xml_parse_ns_list(JSContext *cx, njs_str_t *src);
static int qjs_xml_c14n_visibility_cb(void *user_data, xmlNode *node,
    xmlNode *parent);
static int qjs_xml_buf_write_cb(void *context, const char *buffer, int len);
static qjs_xml_nset_t *qjs_xml_nset_create(JSContext *cx, xmlDoc *doc,
    xmlNode *current, qjs_xml_nset_type_t type);
static qjs_xml_nset_t *qjs_xml_nset_add(qjs_xml_nset_t *nset,
    qjs_xml_nset_t *add);
static void qjs_xml_nset_free(JSContext *cx, qjs_xml_nset_t *nset);
static qjs_xml_node_t *qjs_xml_ns_args(JSContext *cx, JSValueConst this_val,
    JSValueConst *argv, njs_str_t *uri, njs_str_t *local);
static void qjs_xml_ns_args_free(JSContext *cx, njs_str_t *uri,
    njs_str_t *local);
static int qjs_xml_ns_match(const xmlChar *name, xmlNs *ns, njs_str_t *uri,
    njs_str_t *local);
static int qjs_xml_node_is_live(xmlNode *node);
static xmlNode *qjs_xml_list_detach(xmlNode *parent, njs_str_t *name);
static int qjs_xml_list_retire(JSContext *cx, qjs_xml_doc_t *doc,
    xmlNode *parent, njs_str_t *name);
static void qjs_xml_list_append(xmlNode *parent, xmlNode *node);
static int qjs_xml_tree_has_namespaces(xmlNode *node);

static void qjs_xml_error(JSContext *cx, xmlParserCtxt *ctx,
    const char *fmt, ...);
static JSModuleDef *qjs_xml_init(JSContext *ctx, const char *name);


static const JSCFunctionListEntry qjs_xml_export[] = {
    JS_CFUNC_DEF("parse", 2, qjs_xml_parse),
    JS_CFUNC_MAGIC_DEF("c14n", 4, qjs_xml_canonicalization, 0),
    JS_CFUNC_MAGIC_DEF("exclusiveC14n", 4, qjs_xml_canonicalization, 1),
    JS_CFUNC_MAGIC_DEF("serialize", 4, qjs_xml_canonicalization, 0),
    JS_CFUNC_MAGIC_DEF("serializeToString", 4, qjs_xml_canonicalization, 2),
};


static const JSCFunctionListEntry qjs_xml_doc_proto[] = {
    JS_PROP_STRING_DEF("[Symbol.toStringTag]", "XMLDoc", JS_PROP_CONFIGURABLE),
};


static const JSCFunctionListEntry qjs_xml_node_proto[] = {
    JS_PROP_STRING_DEF("[Symbol.toStringTag]", "XMLNode", JS_PROP_CONFIGURABLE),
    JS_CFUNC_DEF("addChild", 1, qjs_xml_node_add_child),
    JS_CFUNC_DEF("getAttributeNS", 2, qjs_xml_node_get_attribute_ns),
    JS_CFUNC_DEF("getChildNS", 2, qjs_xml_node_get_child_ns),
    JS_CFUNC_DEF("removeChildren", 1, qjs_xml_node_remove_children),
    JS_CFUNC_DEF("setAttribute", 2, qjs_xml_node_set_attribute),
    JS_CFUNC_DEF("removeAttribute", 1, qjs_xml_node_remove_attribute),
    JS_CFUNC_DEF("removeAllAttributes", 0, qjs_xml_node_remove_all_attributes),
    JS_CFUNC_DEF("setText", 1, qjs_xml_node_set_text),
    JS_CFUNC_DEF("removeText", 0, qjs_xml_node_remove_text),
};


static const JSCFunctionListEntry qjs_xml_attr_proto[] = {
    JS_PROP_STRING_DEF("[Symbol.toStringTag]", "XMLAttr", JS_PROP_CONFIGURABLE),
};


static JSClassDef qjs_xml_doc_class = {
    "XMLDoc",
    .finalizer = qjs_xml_doc_finalizer,
    .exotic = & (JSClassExoticMethods) {
        .get_own_property = qjs_xml_doc_get_own_property,
        .get_own_property_names = qjs_xml_doc_get_own_property_names,
    },
};


static JSClassDef qjs_xml_node_class = {
    "XMLNode",
    .finalizer = qjs_xml_node_finalizer,
    .exotic = & (JSClassExoticMethods) {
        .get_own_property = qjs_xml_node_get_own_property,
        .get_own_property_names = qjs_xml_node_get_own_property_names,
        .set_property = qjs_xml_node_set_property,
        .delete_property = qjs_xml_node_delete_property,
        .define_own_property = qjs_xml_node_define_own_property,
    },
};


static JSClassDef qjs_xml_attr_class = {
    "XMLAttr",
    .finalizer = qjs_xml_attr_finalizer,
    .exotic = & (JSClassExoticMethods) {
        .get_own_property = qjs_xml_attr_get_own_property,
        .get_own_property_names = qjs_xml_attr_get_own_property_names,
    },
};


qjs_module_t  qjs_xml_module = {
    .name = "xml",
    .init = qjs_xml_init,
};


static JSValue
qjs_xml_parse(JSContext *cx, JSValueConst this_val, int argc,
    JSValueConst *argv)
{
    JSValue        ret;
    qjs_bytes_t    data;
    xmlParserCtxt  *ctx;
    qjs_xml_doc_t  *tree;

    if (qjs_to_bytes(cx, &data, argv[0]) < 0) {
        return JS_EXCEPTION;
    }

    tree = js_mallocz(cx, sizeof(qjs_xml_doc_t));
    if (tree == NULL) {
        qjs_bytes_free(cx, &data);
        JS_ThrowOutOfMemory(cx);
        return JS_EXCEPTION;
    }

    tree->ref_count = 1;

    ctx = xmlNewParserCtxt();
    if (ctx == NULL) {
        qjs_bytes_free(cx, &data);
        JS_ThrowInternalError(cx, "xmlNewParserCtxt() failed");
        qjs_xml_doc_free(JS_GetRuntime(cx), tree);
        return JS_EXCEPTION;
    }

    tree->doc = xmlCtxtReadMemory(ctx, (char *) data.start, data.length,
                                   NULL, NULL, XML_PARSE_NOWARNING
                                               | XML_PARSE_NOERROR);
    qjs_bytes_free(cx, &data);
    if (tree->doc == NULL) {
        qjs_xml_error(cx, ctx, "failed to parse XML");
        xmlFreeParserCtxt(ctx);
        qjs_xml_doc_free(JS_GetRuntime(cx), tree);
        return JS_EXCEPTION;
    }

    xmlFreeParserCtxt(ctx);

    ret = JS_NewObjectClass(cx, QJS_CORE_CLASS_ID_XML_DOC);
    if (JS_IsException(ret)) {
        qjs_xml_doc_free(JS_GetRuntime(cx), tree);
        return ret;
    }

    JS_SetOpaque(ret, tree);

    return ret;
}


static JSValue
qjs_xml_canonicalization(JSContext *cx, JSValueConst this_val, int argc,
    JSValueConst *argv, int magic)
{
    int              comments;
    u_char           **prefix_list;
    xmlDoc           *doc;
    xmlNode          *node;
    ssize_t          size;
    JSValue          excluding, prefixes, ret;
    njs_str_t        pref;
    njs_chb_t        chain;
    qjs_xml_node_t   *nd;
    qjs_xml_nset_t   *nset, *children;
    xmlOutputBuffer  *buf;

    node = qjs_xml_node(cx, argv[0], &doc);
    if (node == NULL) {
        return JS_EXCEPTION;
    }

    if (!qjs_xml_node_is_live(node)) {
        JS_ThrowTypeError(cx, "XMLNode is detached");
        return JS_EXCEPTION;
    }

    comments = JS_ToBool(cx, argv[2]);
    if (comments < 0) {
        return JS_EXCEPTION;
    }

    buf = NULL;
    nset = NULL;
    children = NULL;

    excluding = argv[1];
    if (!JS_IsNullOrUndefined(excluding)) {
        nd = JS_GetOpaque(excluding, QJS_CORE_CLASS_ID_XML_NODE);
        if (nd == NULL) {
            JS_ThrowTypeError(cx, "\"excluding\" argument is not a XMLNode "
                              "object");
            return JS_EXCEPTION;
        }

        if (nd->doc->doc != doc
            || !qjs_xml_node_is_live(nd->node))
        {
            JS_ThrowTypeError(cx, "\"excluding\" is not in XMLNode tree");
            return JS_EXCEPTION;
        }

        nset = qjs_xml_nset_create(cx, doc, node, XML_NSET_TREE_NO_COMMENTS);
        if (nset == NULL) {
            return JS_ThrowOutOfMemory(cx);
        }

        children = qjs_xml_nset_create(cx, nd->doc->doc, nd->node,
                                       XML_NSET_TREE_INVERT);
        if (children == NULL) {
            qjs_xml_nset_free(cx, nset);
            return JS_ThrowOutOfMemory(cx);
        }

        nset = qjs_xml_nset_add(nset, children);

    } else {
        nset = qjs_xml_nset_create(cx, doc, node,
                                   comments ? XML_NSET_TREE
                                            : XML_NSET_TREE_NO_COMMENTS);
        if (nset == NULL) {
            return JS_ThrowOutOfMemory(cx);
        }
    }

    prefix_list = NULL;
    prefixes = argv[3];
    if (!JS_IsNullOrUndefined(prefixes)) {
        if (!JS_IsString(prefixes)) {
            JS_ThrowTypeError(cx, "\"prefixes\" argument is not a string");
            goto fail;
        }

        pref.start = (u_char *) JS_ToCStringLen(cx, &pref.length, prefixes);
        if (pref.start == NULL) {
            goto fail;
        }

        prefix_list = qjs_xml_parse_ns_list(cx, &pref);

        JS_FreeCString(cx, (char *) pref.start);

        if (prefix_list == NULL) {
            goto fail;
        }
    }

    NJS_CHB_CTX_INIT(&chain, cx);

    buf = xmlOutputBufferCreateIO(qjs_xml_buf_write_cb, NULL,
                                  &chain, NULL);
    if (buf == NULL) {
        JS_ThrowInternalError(cx, "xmlOutputBufferCreateIO() failed");
        goto fail;
    }

    size = xmlC14NExecute(doc, qjs_xml_c14n_visibility_cb, nset,
                          magic & 0x1 ? XML_C14N_EXCLUSIVE_1_0 : XML_C14N_1_0,
                          prefix_list, comments, buf);

    if (size < 0) {
        njs_chb_destroy(&chain);
        (void) xmlOutputBufferClose(buf);
        JS_ThrowInternalError(cx, "xmlC14NExecute() failed");
        goto fail;
    }

    if (magic & 0x2) {
        ret = qjs_string_create_chb(cx, &chain);

    } else {
        ret = qjs_buffer_chb_alloc(cx, &chain);
        njs_chb_destroy(&chain);
    }

    (void) xmlOutputBufferClose(buf);

    qjs_xml_nset_free(cx, nset);
    qjs_xml_nset_free(cx, children);

    if (prefix_list != NULL) {
        js_free(cx, prefix_list);
    }

    return ret;

fail:

    qjs_xml_nset_free(cx, nset);
    qjs_xml_nset_free(cx, children);

    if (prefix_list != NULL) {
        js_free(cx, prefix_list);
    }

    return JS_EXCEPTION;
}


static int
qjs_xml_doc_get_own_property(JSContext *cx, JSPropertyDescriptor *pdesc,
    JSValueConst obj, JSAtom prop)
{
    int            any;
    xmlNode        *node;
    njs_str_t      name;
    qjs_xml_doc_t  *tree;

    tree = JS_GetOpaque(obj, QJS_CORE_CLASS_ID_XML_DOC);
    if (tree == NULL) {
        (void) JS_ThrowTypeError(cx, "\"this\" is not an XMLDoc");
        return -1;
    }

    name.start = (u_char *) JS_AtomToCString(cx, prop);
    if (name.start == NULL) {
        return -1;
    }

    name.length = njs_strlen(name.start);

    any = (name.length == njs_strlen("$root")
           && njs_strncmp(name.start, "$root", name.length) == 0);

    for (node = xmlDocGetRootElement(tree->doc);
         node != NULL;
         node = node->next)
    {
        if (node->type != XML_ELEMENT_NODE) {
            continue;
        }

        if (!any) {
            if (name.length != njs_strlen(node->name)
                || njs_strncmp(name.start, node->name, name.length) != 0)
            {
                continue;
            }
        }

        JS_FreeCString(cx, (char *) name.start);

        if (pdesc != NULL) {
            pdesc->flags = JS_PROP_ENUMERABLE;
            pdesc->getter = JS_UNDEFINED;
            pdesc->setter = JS_UNDEFINED;
            pdesc->value  = qjs_xml_node_make(cx, tree, node);
            if (JS_IsException(pdesc->value)) {
                return -1;
            }
        }

        return 1;
    }

    JS_FreeCString(cx, (char *) name.start);

    return 0;
}


static int
qjs_xml_push_string(JSContext *cx, JSValue obj, const char *start)
{
    JSAtom  key;

    key = JS_NewAtomLen(cx, start, njs_strlen(start));
    if (key == JS_ATOM_NULL) {
        return -1;
    }

    if (JS_DefinePropertyValue(cx, obj, key, JS_UNDEFINED,
                               JS_PROP_ENUMERABLE) < 0)
    {
        JS_FreeAtom(cx, key);
        return -1;
    }

    JS_FreeAtom(cx, key);

    return 0;
}


static int
qjs_xml_doc_get_own_property_names(JSContext *cx, JSPropertyEnum **ptab,
    uint32_t *plen, JSValueConst obj)
{
    int            rc;
    JSValue        keys;
    xmlNode        *node;
    qjs_xml_doc_t  *tree;

    tree = JS_GetOpaque(obj, QJS_CORE_CLASS_ID_XML_DOC);
    if (tree == NULL) {
        (void) JS_ThrowTypeError(cx, "\"this\" is not an XMLDoc");
        return -1;
    }

    keys = JS_NewObject(cx);
    if (JS_IsException(keys)) {
        return -1;
    }

    for (node = xmlDocGetRootElement(tree->doc);
         node != NULL;
         node = node->next)
    {
        if (node->type != XML_ELEMENT_NODE) {
            continue;
        }

        if (qjs_xml_push_string(cx, keys, (char *) node->name) < 0) {
            JS_FreeValue(cx, keys);
            return -1;
        }
    }

    rc = JS_GetOwnPropertyNames(cx, ptab, plen, keys, JS_GPN_STRING_MASK);

    JS_FreeValue(cx, keys);

    return rc;
}


static void
qjs_xml_doc_free(JSRuntime *rt, qjs_xml_doc_t *current)
{
    qjs_xml_retired_t  *retired, *next;

    if (--current->ref_count > 0) {
        return;
    }

    for (retired = current->retired; retired != NULL; retired = next) {
        next = retired->next;
        xmlFreeNodeList(retired->nodes);
        js_free_rt(rt, retired);
    }

    if (current->doc != NULL) {
        xmlFreeDoc(current->doc);
    }

    js_free_rt(rt, current);
}


static void
qjs_xml_doc_finalizer(JSRuntime *rt, JSValue val)
{
    qjs_xml_doc_t  *current;

    current = JS_GetOpaque(val, QJS_CORE_CLASS_ID_XML_DOC);

    qjs_xml_doc_free(rt, current);
}


static JSValue
qjs_xml_node_make(JSContext *cx, qjs_xml_doc_t *doc, xmlNode *node)
{
    JSValue         ret;
    qjs_xml_node_t  *current;

    current = js_malloc(cx, sizeof(qjs_xml_node_t));
    if (current == NULL) {
        JS_ThrowOutOfMemory(cx);
        return JS_EXCEPTION;
    }

    current->node = node;
    current->doc = doc;

    ret = JS_NewObjectClass(cx, QJS_CORE_CLASS_ID_XML_NODE);
    if (JS_IsException(ret)) {
        js_free(cx, current);
        return ret;
    }

    doc->ref_count++;
    JS_SetOpaque(ret, current);

    return ret;
}


static JSValue
qjs_xml_node_tag_handler(JSContext *cx, qjs_xml_node_t *current,
    njs_str_t *name)
{
    size_t   size;
    xmlNode  *node;

    node = current->node;

    for (node = node->children; node != NULL; node = node->next) {
        if (node->type != XML_ELEMENT_NODE) {
            continue;
        }

        size = njs_strlen(node->name);

        if (name->length > 0
            && (name->length != size
                || njs_strncmp(name->start, node->name, size) != 0))
        {
            continue;
        }

        return qjs_xml_node_make(cx, current->doc, node);
    }

    return JS_UNDEFINED;
}


static JSValue
qjs_xml_node_tags_handler(JSContext *cx, qjs_xml_node_t *current,
    njs_str_t *name)
{
    size_t   size;
    int32_t  i;
    xmlNode  *node;
    JSValue  arr, ret;

    arr = JS_NewArray(cx);
    if (JS_IsException(arr)) {
        return arr;
    }

    i = 0;
    node = current->node;

    for (node = node->children; node != NULL; node = node->next) {
        if (node->type != XML_ELEMENT_NODE) {
            continue;
        }

        size = njs_strlen(node->name);

        if (name->length > 0
            && (name->length != size
                || njs_strncmp(name->start, node->name, size) != 0))
        {
            continue;
        }

        ret = qjs_xml_node_make(cx, current->doc, node);
        if (JS_IsException(ret)) {
            JS_FreeValue(cx, arr);
            return JS_EXCEPTION;
        }

        if (JS_SetPropertyUint32(cx, arr, i++, ret) < 0) {
            JS_FreeValue(cx, arr);
            return JS_EXCEPTION;
        }
    }

    return arr;
}


static JSValue
qjs_xml_node_attr_handler(JSContext *cx, qjs_xml_node_t *current,
    njs_str_t *name)
{
    size_t   size;
    xmlAttr  *attr;
    xmlNode  *node;

    node = current->node;

    for (attr = node->properties; attr != NULL; attr = attr->next) {
        if (attr->type != XML_ATTRIBUTE_NODE) {
            continue;
        }

        size = njs_strlen(attr->name);

        if (name->length > 0
            && (name->length != size
                || njs_strncmp(name->start, attr->name, size) != 0))
        {
            continue;
        }

        return qjs_xml_attr_value(cx, attr);
    }

    return JS_UNDEFINED;
}


static JSValue
qjs_xml_attr_value(JSContext *cx, xmlAttr *attr)
{
    JSValue  value;
    xmlChar  *text;

    text = xmlNodeGetContent((xmlNode *) attr);
    if (text == NULL) {
        JS_ThrowInternalError(cx, "xmlNodeGetContent() failed");
        return JS_EXCEPTION;
    }

    value = JS_NewString(cx, (char *) text);
    xmlFree(text);

    return value;
}


static int
qjs_xml_node_attr_modify(JSContext *cx, JSValue current, const u_char *name,
    JSValue setval)
{
    xmlAttr         *attr;
    const u_char    *value;
    qjs_xml_node_t  *node;

    node = JS_GetOpaque(current, QJS_CORE_CLASS_ID_XML_NODE);
    if (node == NULL) {
        return -1;
    }

    if (!qjs_xml_node_is_live(node->node)) {
        JS_ThrowTypeError(cx, "XMLNode is detached");
        return -1;
    }

    if (xmlValidateQName(name, 0) != 0) {
        JS_ThrowTypeError(cx, "attribute name \"%s\" is not valid", name);
        return -1;
    }

    if (JS_IsNullOrUndefined(setval)) {
        attr = xmlHasProp(node->node, name);

        if (attr != NULL) {
            xmlRemoveProp(attr);
        }

        return 1;
    }

    if (!JS_IsString(setval)) {
        JS_ThrowTypeError(cx, "setval is not a string");
        return -1;
    }

    value = (const u_char *) JS_ToCString(cx, setval);
    if (value == NULL) {
        return -1;
    }

    attr = xmlSetProp(node->node, name, value);
    JS_FreeCString(cx, (char *) value);
    if (attr == NULL) {
        JS_ThrowInternalError(cx, "xmlSetProp() failed");
        return -1;
    }

    return 1;
}


static int
qjs_xml_node_tag_modify(JSContext *cx, JSValue obj, njs_str_t *name,
    int delete)
{
    xmlNode         *node;
    qjs_xml_node_t  *current;

    current = JS_GetOpaque(obj, QJS_CORE_CLASS_ID_XML_NODE);
    if (current == NULL) {
        return -1;
    }

    if (!qjs_xml_node_is_live(current->node)) {
        JS_ThrowTypeError(cx, "XMLNode is detached");
        return -1;
    }

    if (!delete) {
        JS_ThrowTypeError(cx, "XMLNode.$tag$xxx is not assignable, "
                          "use addChild() or node.$tags = [node1, node2, ..] "
                          "syntax");
        return -1;
    }

    if (name->length == 0) {
        if (current->node->children != NULL) {
            return qjs_xml_list_retire(cx, current->doc, current->node, NULL);
        }

        return 1;
    }

    for (node = current->node->children; node != NULL; node = node->next) {
        if (node->type == XML_ELEMENT_NODE
            && name->length == njs_strlen(node->name)
            && njs_strncmp(name->start, node->name, name->length) == 0)
        {
            break;
        }
    }

    if (node != NULL) {
        return qjs_xml_list_retire(cx, current->doc, current->node, name);
    }

    return 1;
}


static int
qjs_xml_node_tags_modify(JSContext *cx, JSValue obj, njs_str_t *name,
    JSValue setval)
{
    JSValue         length, v;
    xmlNode         *first, *last, *node;
    uint32_t        len, i;
    qjs_xml_node_t  *current;

    current = JS_GetOpaque(obj, QJS_CORE_CLASS_ID_XML_NODE);
    if (current == NULL) {
        return -1;
    }

    if (!qjs_xml_node_is_live(current->node)) {
        JS_ThrowTypeError(cx, "XMLNode is detached");
        return -1;
    }

    if (name->length > 0) {
        JS_ThrowTypeError(cx, "XMLNode $tags$xxx is not assignable, use "
                          "addChild() or node.$tags = [node1, node2, ..] "
                          "syntax");
        return -1;
    }

    if (JS_IsNullOrUndefined(setval)) {
        if (current->node->children == NULL) {
            return 1;
        }

        return qjs_xml_list_retire(cx, current->doc, current->node, NULL);
    }

    if (!qjs_is_array(cx, setval)) {
        JS_ThrowTypeError(cx, "setval is not an array");
        return -1;
    }

    length = JS_GetPropertyStr(cx, setval, "length");
    if (JS_IsException(length)) {
        return -1;
    }

    if (JS_ToUint32(cx, &len, length) < 0) {
        JS_FreeValue(cx, length);
        return -1;
    }

    JS_FreeValue(cx, length);

    first = NULL;
    last = NULL;

    for (i = 0; i < len; i++) {
        v = JS_GetPropertyUint32(cx, setval, i);
        if (JS_IsException(v)) {
            goto error;
        }

        node = qjs_xml_node(cx, v, NULL);
        if (node == NULL) {
            JS_FreeValue(cx, v);
            goto error;
        }

        if (qjs_xml_tree_has_namespaces(node)) {
            JS_FreeValue(cx, v);
            JS_ThrowTypeError(cx, "setval[%u] has namespaces", i);
            goto error;
        }

        node = xmlDocCopyNode(node, current->doc->doc, 1);
        JS_FreeValue(cx, v);
        if (node == NULL) {
            JS_ThrowInternalError(cx, "xmlDocCopyNode() failed");
            goto error;
        }

        node->parent = NULL;
        node->prev = last;
        node->next = NULL;

        if (last != NULL) {
            last->next = node;

        } else {
            first = node;
        }

        last = node;
    }

    if (!qjs_xml_node_is_live(current->node)) {
        JS_ThrowTypeError(cx, "XMLNode is detached");
        goto error;
    }

    if (current->node->children != NULL) {
        if (qjs_xml_list_retire(cx, current->doc, current->node, NULL) < 0) {
            goto error;
        }
    }

    current->node->children = first;
    current->node->last = last;

    for (node = first; node != NULL; node = node->next) {
        node->parent = current->node;
    }

    return 1;

error:

    xmlFreeNodeList(first);

    return -1;
}


static int
qjs_xml_node_text_handler(JSContext *cx, JSValue current, JSValue setval)
{
    xmlNode         *text;
    njs_str_t       content;
    qjs_xml_node_t  *node;

    content.start = NULL;
    content.length = 0;

    node = JS_GetOpaque(current, QJS_CORE_CLASS_ID_XML_NODE);
    if (node == NULL) {
        return -1;
    }

    if (!qjs_xml_node_is_live(node->node)) {
        JS_ThrowTypeError(cx, "XMLNode is detached");
        return -1;
    }

    if (!JS_IsNullOrUndefined(setval)) {
        if (!JS_IsString(setval)) {
            JS_ThrowTypeError(cx, "setval is not a string");
            return -1;
        }

        content.start = (u_char *) JS_ToCStringLen(cx, &content.length, setval);
        if (content.start == NULL) {
            return -1;
        }

        if (memchr(content.start, '\0', content.length) != NULL) {
            JS_FreeCString(cx, (char *) content.start);
            JS_ThrowTypeError(cx, "setval contains NUL");
            return -1;
        }
    }

    text = NULL;
    if (!JS_IsNullOrUndefined(setval)) {
        text = xmlNewDocTextLen(node->doc->doc, content.start, content.length);
        JS_FreeCString(cx, (char *) content.start);
        if (text == NULL) {
            JS_ThrowInternalError(cx, "xmlNewDocTextLen() failed");
            return -1;
        }
    }

    if (node->node->children != NULL) {
        if (qjs_xml_list_retire(cx, node->doc, node->node, NULL) < 0) {
            xmlFreeNode(text);
            return -1;
        }
    }

    if (text != NULL) {
        qjs_xml_list_append(node->node, text);
    }

    return 1;
}


static int
qjs_xml_node_has_method(JSContext *cx, JSValueConst obj, JSAtom prop,
    njs_str_t *name)
{
    int                         rc;
    size_t                      i, length;
    JSValue                     proto;
    const JSCFunctionListEntry  *entry;

    for (i = 0; i < njs_nitems(qjs_xml_node_proto); i++) {
        entry = &qjs_xml_node_proto[i];

        if (entry->def_type != JS_DEF_CFUNC) {
            continue;
        }

        length = njs_strlen(entry->name);

        if (name->length == length
            && njs_strncmp(name->start, entry->name, length) == 0)
        {
            proto = JS_GetPrototype(cx, obj);
            if (JS_IsException(proto)) {
                return -1;
            }

            rc = JS_IsObject(proto) ? JS_GetOwnProperty(cx, NULL, proto, prop)
                                    : 0;
            JS_FreeValue(cx, proto);

            return rc;
        }
    }

    return 0;
}


static int
qjs_xml_node_get_own_property(JSContext *cx, JSPropertyDescriptor *pdesc,
    JSValueConst obj, JSAtom prop)
{
    int             rc;
    u_char          *text;
    JSValue         value;
    xmlNode         *node;
    njs_str_t       name, nm;
    qjs_xml_node_t  *current;

    /*
     * $tag$foo - the first tag child with the name "foo"
     * $tags$foo - the all children with the name "foo" as an array
     * $attr$foo - the attribute with the name "foo"
     * foo - the same as $tag$foo
     */

    current = JS_GetOpaque(obj, QJS_CORE_CLASS_ID_XML_NODE);
    if (current == NULL) {
        (void) JS_ThrowTypeError(cx, "\"this\" is not an XMLNode");
        return -1;
    }

    name.start = (u_char *) JS_AtomToCString(cx, prop);
    if (name.start == NULL) {
        return -1;
    }

    name.length = njs_strlen(name.start);
    node = current->node;

    if (name.length > 1 && name.start[0] == '$') {
        if (name.length == njs_length("$attrs")
            && njs_strncmp(&name.start[1], "attrs", njs_length("attrs")) == 0)
        {
            JS_FreeCString(cx, (char *) name.start);

            if (node->properties == NULL) {
                return 0;
            }

            if (pdesc != NULL) {
                pdesc->flags = JS_PROP_ENUMERABLE;
                pdesc->getter = JS_UNDEFINED;
                pdesc->setter = JS_UNDEFINED;
                pdesc->value  = qjs_xml_attr_make(cx, current->doc, node);
                if (JS_IsException(pdesc->value)) {
                    return -1;
                }
            }

            return 1;
        }

        if (name.length > njs_length("$attr$")
            && njs_strncmp(&name.start[1], "attr$", njs_length("attr$")) == 0)
        {
            nm.length = name.length - njs_length("$attr$");
            nm.start = name.start + njs_length("$attr$");

            value = qjs_xml_node_attr_handler(cx, current, &nm);
            JS_FreeCString(cx, (char *) name.start);
            if (JS_IsException(value)) {
                return -1;
            }

            if (JS_IsUndefined(value)) {
                return 0;
            }

            if (pdesc == NULL) {
                JS_FreeValue(cx, value);
                return 1;
            }

            pdesc->flags = JS_PROP_ENUMERABLE;
            pdesc->getter = JS_UNDEFINED;
            pdesc->setter = JS_UNDEFINED;
            pdesc->value  = value;

            return 1;
        }

        if (name.length == njs_length("$name")
            && njs_strncmp(&name.start[1], "name", njs_length("name")) == 0)
        {
            JS_FreeCString(cx, (char *) name.start);

            if (node->type != XML_ELEMENT_NODE) {
                return 0;
            }

            if (pdesc != NULL) {
                pdesc->flags = JS_PROP_ENUMERABLE;
                pdesc->getter = JS_UNDEFINED;
                pdesc->setter = JS_UNDEFINED;
                pdesc->value  = JS_NewString(cx, (char *) node->name);
                if (JS_IsException(pdesc->value)) {
                    return -1;
                }
            }

            return 1;
        }

        if (name.length == njs_length("$ns")
            && njs_strncmp(&name.start[1], "ns", njs_length("ns")) == 0)
        {
            JS_FreeCString(cx, (char *) name.start);

            if (node->ns == NULL || node->ns->href == NULL) {
                return 0;
            }

            if (pdesc != NULL) {
                pdesc->flags = JS_PROP_ENUMERABLE;
                pdesc->getter = JS_UNDEFINED;
                pdesc->setter = JS_UNDEFINED;
                pdesc->value  = JS_NewString(cx, (char *) node->ns->href);
                if (JS_IsException(pdesc->value)) {
                    return -1;
                }
            }

            return 1;
        }

        if (name.length == njs_length("$parent")
            && njs_strncmp(&name.start[1], "parent", njs_length("parent")) == 0)
        {
            JS_FreeCString(cx, (char *) name.start);

            if (node->parent == NULL
                || node->parent->type != XML_ELEMENT_NODE)
            {
                return 0;
            }

            if (pdesc != NULL) {
                pdesc->flags = JS_PROP_ENUMERABLE;
                pdesc->getter = JS_UNDEFINED;
                pdesc->setter = JS_UNDEFINED;
                pdesc->value  = qjs_xml_node_make(cx, current->doc,
                                                  node->parent);
                if (JS_IsException(pdesc->value)) {
                    return -1;
                }
            }

            return 1;
        }

        if (name.length == njs_length("$tags")
            && njs_strncmp(&name.start[1], "tags", njs_length("tags")) == 0)
        {
            JS_FreeCString(cx, (char *) name.start);

            if (pdesc != NULL) {
                nm.start = NULL;
                nm.length = 0;

                pdesc->flags = JS_PROP_ENUMERABLE;
                pdesc->getter = JS_UNDEFINED;
                pdesc->setter = JS_UNDEFINED;
                pdesc->value  = qjs_xml_node_tags_handler(cx, current, &nm);
                if (JS_IsException(pdesc->value)) {
                    return -1;
                }
            }

            return 1;
        }

        if (name.length > njs_length("$tags$")
            && njs_strncmp(&name.start[1], "tags$", njs_length("tags$")) == 0)
        {
            nm.start = name.start + njs_length("$tags$");
            nm.length = name.length - njs_length("$tags$");

            value = qjs_xml_node_tags_handler(cx, current, &nm);
            JS_FreeCString(cx, (char *) name.start);
            if (JS_IsException(value)) {
                return -1;
            }

            if (pdesc == NULL) {
                JS_FreeValue(cx, value);
                return 1;
            }

            pdesc->flags = JS_PROP_ENUMERABLE;
            pdesc->getter = JS_UNDEFINED;
            pdesc->setter = JS_UNDEFINED;
            pdesc->value = value;

            return 1;
        }

        if (name.length > njs_length("$tag$")
            && njs_strncmp(&name.start[1], "tag$", njs_length("tag$")) == 0)
        {
            nm.length = name.length - njs_length("$tag$");
            nm.start = name.start + njs_length("$tag$");
            goto tag;
        }

        if (name.length == njs_length("$text")
            && njs_strncmp(&name.start[1], "text", njs_length("text")) == 0)
        {
            JS_FreeCString(cx, (char *) name.start);

            text = xmlNodeGetContent(current->node);
            if (text == NULL) {
                return 0;
            }

            if (pdesc != NULL) {
                pdesc->flags = JS_PROP_ENUMERABLE;
                pdesc->getter = JS_UNDEFINED;
                pdesc->setter = JS_UNDEFINED;
                pdesc->value = JS_NewString(cx, (char *) text);
                if (JS_IsException(pdesc->value)) {
                    xmlFree(text);
                    return -1;
                }
            }

            xmlFree(text);

            return 1;
        }
    }

    nm = name;

    rc = qjs_xml_node_has_method(cx, obj, prop, &name);
    if (rc != 0) {
        JS_FreeCString(cx, (char *) name.start);
        return rc < 0 ? -1 : 0;
    }

tag:

    value = qjs_xml_node_tag_handler(cx, current, &nm);
    JS_FreeCString(cx, (char *) name.start);
    if (JS_IsException(value)) {
        return -1;
    }

    if (JS_IsUndefined(value)) {
        return 0;
    }

    if (pdesc == NULL) {
        JS_FreeValue(cx, value);
        return 1;
    }

    pdesc->flags = JS_PROP_ENUMERABLE;
    pdesc->getter = JS_UNDEFINED;
    pdesc->setter = JS_UNDEFINED;
    pdesc->value  = value;

    return 1;
}


static int
qjs_xml_node_get_own_property_names(JSContext *cx, JSPropertyEnum **ptab,
    uint32_t *plen, JSValueConst obj)
{
    int             rc;
    JSValue         keys;
    xmlNode         *node, *current;
    qjs_xml_node_t  *tree;

    tree = JS_GetOpaque(obj, QJS_CORE_CLASS_ID_XML_NODE);
    if (tree == NULL) {
        (void) JS_ThrowTypeError(cx, "\"this\" is not an XMLNode");
        return -1;
    }

    keys = JS_NewObject(cx);
    if (JS_IsException(keys)) {
        return -1;
    }

    current = tree->node;

    if (current->name != NULL && current->type == XML_ELEMENT_NODE) {
        if (qjs_xml_push_string(cx, keys, "$name") < 0) {
            goto fail;
        }
    }

    if (current->ns != NULL) {
        if (qjs_xml_push_string(cx, keys, "$ns") < 0) {
            goto fail;
        }
    }

    if (current->properties != NULL) {
        if (qjs_xml_push_string(cx, keys, "$attrs") < 0) {
            goto fail;
        }
    }

    if (current->children != NULL && current->children->content != NULL) {
        if (qjs_xml_push_string(cx, keys, "$text") < 0) {
            goto fail;
        }
    }

    for (node = current->children; node != NULL; node = node->next) {
        if (node->type != XML_ELEMENT_NODE) {
            continue;
        }

        if (qjs_xml_push_string(cx, keys, "$tags") < 0) {
            goto fail;
        }

        break;
    }

    rc = JS_GetOwnPropertyNames(cx, ptab, plen, keys, JS_GPN_STRING_MASK);

    JS_FreeValue(cx, keys);

    return rc;

fail:

    JS_FreeValue(cx, keys);

    return -1;
}

static int
qjs_xml_node_set_property(JSContext *cx, JSValueConst obj, JSAtom atom,
    JSValueConst value, JSValueConst receiver, int flags)
{
    return qjs_xml_node_property_modify(cx, obj, atom, value, 0);
}


static int
qjs_xml_node_delete_property(JSContext *cx, JSValueConst obj, JSAtom prop)
{
    return qjs_xml_node_property_modify(cx, obj, prop, JS_UNDEFINED, 1);
}


static int
qjs_xml_node_define_own_property(JSContext *cx, JSValueConst obj, JSAtom atom,
    JSValueConst value, JSValueConst getter, JSValueConst setter, int flags)
{
    return qjs_xml_node_property_modify(cx, obj, atom, value, 0);
}


static int
qjs_xml_node_property_modify(JSContext *cx, JSValueConst obj, JSAtom atom,
    JSValueConst value, int delete)
{
    int        rc;
    njs_str_t  name, nm;

    name.start = (u_char *) JS_AtomToCString(cx, atom);
    if (name.start == NULL) {
        return -1;
    }

    name.length = njs_strlen(name.start);

    if (name.length > 1 && name.start[0] == '$') {
        if (name.length > njs_length("$attr$")
            && njs_strncmp(&name.start[1], "attr$", njs_length("attr$")) == 0)
        {
            nm.start = name.start + njs_length("$attr$");

            rc = qjs_xml_node_attr_modify(cx, obj, nm.start, value);

            JS_FreeCString(cx, (char *) name.start);

            return rc;
        }

        if (name.length > njs_length("$tag$")
            && njs_strncmp(&name.start[1], "tag$", njs_length("tag$")) == 0)
        {
            nm.start = name.start + njs_length("$tag$");
            nm.length = name.length - njs_length("$tag$");

            rc = qjs_xml_node_tag_modify(cx, obj, &nm, delete);

            JS_FreeCString(cx, (char *) name.start);

            return rc;
        }

        if (name.length >= njs_length("$tags$")
            && njs_strncmp(&name.start[1], "tags$", njs_length("tags$")) == 0)
        {
            nm.start = name.start + njs_length("$tags$");
            nm.length = name.length - njs_length("$tags$");

            rc = qjs_xml_node_tags_modify(cx, obj, &nm, value);

            JS_FreeCString(cx, (char *) name.start);

            return rc;
        }

        if (name.length >= njs_length("$tags")
            && njs_strncmp(&name.start[1], "tags", njs_length("tags")) == 0)
        {
            nm.start = name.start + njs_length("$tags");
            nm.length = name.length - njs_length("$tags");

            rc = qjs_xml_node_tags_modify(cx, obj, &nm, value);

            JS_FreeCString(cx, (char *) name.start);

            return rc;
        }

        if (name.length == njs_length("$text")
            && njs_strncmp(&name.start[1], "text", njs_length("text")) == 0)
        {
            JS_FreeCString(cx, (char *) name.start);

            return qjs_xml_node_text_handler(cx, obj, value);
        }
    }

    if (delete) {
        rc = qjs_xml_node_has_method(cx, obj, atom, &name);
        if (rc != 0) {
            JS_FreeCString(cx, (char *) name.start);
            return rc < 0 ? -1 : 1;
        }
    }

    rc = qjs_xml_node_tag_modify(cx, obj, &name, delete);
    JS_FreeCString(cx, (char *) name.start);

    return rc;
}


static JSValue
qjs_xml_node_get_attribute_ns(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    xmlAttr         *attr;
    xmlChar         *text;
    JSValue         value;
    njs_str_t       uri, local;
    qjs_xml_node_t  *current;

    current = qjs_xml_ns_args(cx, this_val, argv, &uri, &local);
    if (current == NULL) {
        return JS_EXCEPTION;
    }

    value = JS_UNDEFINED;

    for (attr = current->node->properties; attr != NULL; attr = attr->next) {
        if (!qjs_xml_ns_match(attr->name, attr->ns, &uri, &local)) {
            continue;
        }

        text = xmlNodeGetContent((xmlNode *) attr);
        if (text == NULL) {
            value = JS_ThrowInternalError(cx, "xmlNodeGetContent() failed");
            break;
        }

        value = JS_NewString(cx, (char *) text);
        xmlFree(text);
        break;
    }

    qjs_xml_ns_args_free(cx, &uri, &local);

    return value;
}


static JSValue
qjs_xml_node_get_child_ns(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    JSValue         value;
    xmlNode         *node;
    njs_str_t       uri, local;
    qjs_xml_node_t  *current;

    current = qjs_xml_ns_args(cx, this_val, argv, &uri, &local);
    if (current == NULL) {
        return JS_EXCEPTION;
    }

    value = JS_UNDEFINED;

    for (node = current->node->children; node != NULL; node = node->next) {
        if (node->type == XML_ELEMENT_NODE
            && qjs_xml_ns_match(node->name, node->ns, &uri, &local))
        {
            value = qjs_xml_node_make(cx, current->doc, node);
            break;
        }
    }

    qjs_xml_ns_args_free(cx, &uri, &local);

    return value;
}


static JSValue
qjs_xml_node_add_child(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    xmlNode         *node;
    qjs_xml_node_t  *current;

    current = JS_GetOpaque(this_val, QJS_CORE_CLASS_ID_XML_NODE);
    if (current == NULL) {
        JS_ThrowTypeError(cx, "\"this\" is not a XMLNode object");
        return JS_EXCEPTION;
    }

    if (!qjs_xml_node_is_live(current->node)) {
        JS_ThrowTypeError(cx, "XMLNode is detached");
        return JS_EXCEPTION;
    }

    node = qjs_xml_node(cx, argv[0], NULL);
    if (node == NULL) {
        return JS_EXCEPTION;
    }

    if (qjs_xml_tree_has_namespaces(node)) {
        JS_ThrowTypeError(cx, "XMLNode has namespaces");
        return JS_EXCEPTION;
    }

    node = xmlDocCopyNode(node, current->doc->doc, 1);
    if (node == NULL) {
        JS_ThrowInternalError(cx, "xmlDocCopyNode() failed");
        return JS_EXCEPTION;
    }

    qjs_xml_list_append(current->node, node);

    return JS_UNDEFINED;
}


static JSValue
qjs_xml_node_remove_children(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    int             rc;
    njs_str_t       name;
    qjs_xml_node_t  *current;

    current = JS_GetOpaque(this_val, QJS_CORE_CLASS_ID_XML_NODE);
    if (current == NULL) {
        JS_ThrowTypeError(cx, "\"this\" is not a XMLNode object");
        return JS_EXCEPTION;
    }

    if (!JS_IsNullOrUndefined(argv[0])) {
        if (!JS_IsString(argv[0])) {
            JS_ThrowTypeError(cx, "selector is not a string");
            return JS_EXCEPTION;
        }

        name.start = (u_char *) JS_ToCString(cx, argv[0]);
        if (name.start == NULL) {
            return JS_EXCEPTION;
        }

        name.length = njs_strlen(name.start);

    } else {
        name.start = NULL;
        name.length = 0;
    }

    rc = qjs_xml_node_tag_modify(cx, this_val, &name, 1);

    if (name.start != NULL) {
        JS_FreeCString(cx, (char *) name.start);
    }

    if (rc < 0) {
        return JS_EXCEPTION;
    }

    return JS_UNDEFINED;
}


static JSValue
qjs_xml_node_set_attribute(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    const u_char  *name;

    if (!JS_IsString(argv[0])) {
        JS_ThrowTypeError(cx, "\"name\" argument is not a string");
        return JS_EXCEPTION;
    }

    name = (const u_char *) JS_ToCString(cx, argv[0]);

    if (qjs_xml_node_attr_modify(cx, this_val, name, argv[1]) < 0) {
        JS_FreeCString(cx, (char *) name);
        return JS_EXCEPTION;
    }

    JS_FreeCString(cx, (char *) name);

    return JS_UNDEFINED;
}


static JSValue
qjs_xml_node_remove_attribute(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    const u_char  *name;

    if (!JS_IsString(argv[0])) {
        JS_ThrowTypeError(cx, "\"name\" argument is not a string");
        return JS_EXCEPTION;
    }

    name = (const u_char *) JS_ToCString(cx, argv[0]);

    if (qjs_xml_node_attr_modify(cx, this_val, name, JS_UNDEFINED) < 0) {
        JS_FreeCString(cx, (char *) name);
        return JS_EXCEPTION;
    }

    JS_FreeCString(cx, (char *) name);

    return JS_UNDEFINED;
}


static JSValue
qjs_xml_node_remove_all_attributes(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    xmlNode         *node;
    qjs_xml_node_t  *current;

    current = JS_GetOpaque(this_val, QJS_CORE_CLASS_ID_XML_NODE);
    if (current == NULL) {
        JS_ThrowTypeError(cx, "\"this\" is not a XMLNode object");
        return JS_EXCEPTION;
    }

    if (!qjs_xml_node_is_live(current->node)) {
        JS_ThrowTypeError(cx, "XMLNode is detached");
        return JS_EXCEPTION;
    }

    node = current->node;

    if (node->properties != NULL) {
        xmlFreePropList(node->properties);
        node->properties = NULL;
    }

    return JS_UNDEFINED;
}


static JSValue
qjs_xml_node_set_text(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    if (qjs_xml_node_text_handler(cx, this_val, argv[0]) < 0) {
        return JS_EXCEPTION;
    }

    return JS_UNDEFINED;
}


static JSValue
qjs_xml_node_remove_text(JSContext *cx, JSValueConst this_val,
    int argc, JSValueConst *argv)
{
    if (qjs_xml_node_text_handler(cx, this_val, JS_UNDEFINED) < 0) {
        return JS_EXCEPTION;
    }

    return JS_UNDEFINED;
}


static void
qjs_xml_node_finalizer(JSRuntime *rt, JSValue val)
{
    qjs_xml_node_t  *node;

    node = JS_GetOpaque(val, QJS_CORE_CLASS_ID_XML_NODE);

    qjs_xml_doc_free(rt, node->doc);

    js_free_rt(rt, node);
}


static xmlNode *
qjs_xml_node(JSContext *cx, JSValueConst val, xmlDoc **doc)
{
    qjs_xml_doc_t   *tree;
    qjs_xml_node_t  *current;

    current = JS_GetOpaque(val, QJS_CORE_CLASS_ID_XML_NODE);
    if (current == NULL) {
        tree = JS_GetOpaque(val, QJS_CORE_CLASS_ID_XML_DOC);
        if (tree == NULL) {
            JS_ThrowTypeError(cx, "value is not XMLNode or XMLDoc");
            return NULL;
        }

        if (doc != NULL) {
            *doc = tree->doc;
        }

        return xmlDocGetRootElement(tree->doc);
    }

    if (doc != NULL) {
        *doc = current->doc->doc;
    }

    return current->node;
}


static JSValue
qjs_xml_attr_make(JSContext *cx, qjs_xml_doc_t *doc, xmlNode *node)
{
    JSValue         ret;
    qjs_xml_attr_t  *current;

    current = js_malloc(cx, sizeof(qjs_xml_attr_t));
    if (current == NULL) {
        JS_ThrowOutOfMemory(cx);
        return JS_EXCEPTION;
    }

    current->node = node;
    current->doc = doc;

    ret = JS_NewObjectClass(cx, QJS_CORE_CLASS_ID_XML_ATTR);
    if (JS_IsException(ret)) {
        js_free(cx, current);
        return ret;
    }

    doc->ref_count++;
    JS_SetOpaque(ret, current);

    return ret;
}


static int
qjs_xml_attr_get_own_property(JSContext *cx, JSPropertyDescriptor *pdesc,
    JSValueConst obj, JSAtom prop)
{
    size_t          size;
    xmlAttr         *attr;
    njs_str_t       name;
    qjs_xml_attr_t  *current;

    current = JS_GetOpaque(obj, QJS_CORE_CLASS_ID_XML_ATTR);
    if (current == NULL) {
        (void) JS_ThrowTypeError(cx, "\"this\" is not an XMLAttr");
        return -1;
    }

    name.start = (u_char *) JS_AtomToCString(cx, prop);
    if (name.start == NULL) {
        return -1;
    }

    name.length = njs_strlen(name.start);

    for (attr = current->node->properties; attr != NULL; attr = attr->next) {
        if (attr->type != XML_ATTRIBUTE_NODE) {
            continue;
        }

        size = njs_strlen(attr->name);

        if (name.length != size
            || njs_strncmp(name.start, attr->name, size) != 0)
        {
            continue;
        }

        JS_FreeCString(cx, (char *) name.start);

        if (pdesc != NULL) {
            pdesc->flags = JS_PROP_ENUMERABLE;
            pdesc->getter = JS_UNDEFINED;
            pdesc->setter = JS_UNDEFINED;
            pdesc->value = qjs_xml_attr_value(cx, attr);
            if (JS_IsException(pdesc->value)) {
                return -1;
            }
        }

        return 1;
    }

    JS_FreeCString(cx, (char *) name.start);

    return 0;
}


static int
qjs_xml_attr_get_own_property_names(JSContext *cx, JSPropertyEnum **ptab,
    uint32_t *plen, JSValueConst obj)
{
    int             rc;
    JSValue         keys;
    xmlAttr         *attr;
    qjs_xml_attr_t  *current;

    current = JS_GetOpaque(obj, QJS_CORE_CLASS_ID_XML_ATTR);
    if (current == NULL) {
        (void) JS_ThrowTypeError(cx, "\"this\" is not an XMLAttr");
        return -1;
    }

    keys = JS_NewObject(cx);
    if (JS_IsException(keys)) {
        return -1;
    }

    for (attr = current->node->properties; attr != NULL; attr = attr->next) {
        if (attr->type != XML_ATTRIBUTE_NODE) {
            continue;
        }

        if (qjs_xml_push_string(cx, keys, (char *) attr->name) < 0) {
            goto fail;
        }
    }

    rc = JS_GetOwnPropertyNames(cx, ptab, plen, keys, JS_GPN_STRING_MASK);

    JS_FreeValue(cx, keys);

    return rc;

fail:

    JS_FreeValue(cx, keys);

    return -1;
}


static void
qjs_xml_attr_finalizer(JSRuntime *rt, JSValue val)
{
    qjs_xml_attr_t  *attr;

    attr = JS_GetOpaque(val, QJS_CORE_CLASS_ID_XML_ATTR);

    qjs_xml_doc_free(rt, attr->doc);

    js_free_rt(rt, attr);
}


/* the C14N prefix list is a whitespace delimited list */
#define qjs_xml_ns_sep(c)                                                     \
    ((c) == ' ' || (c) == '\t' || (c) == '\n' || (c) == '\r')


static u_char **
qjs_xml_parse_ns_list(JSContext *cx, njs_str_t *src)
{
    size_t  n;
    u_char  *p, *end, *dst, **buf, **out;

    /*
     * The pointers and the writable copy of the list are allocated as a single
     * block, the copy follows the NULL terminated array of pointers to it.
     * The tokens are counted exactly the way the list is split below.
     */

    n = 0;
    end = src->start + src->length;

    for (p = src->start; p < end && *p != '\0'; /* void */) {
        if (qjs_xml_ns_sep(*p)) {
            p++;
            continue;
        }

        n++;

        while (p < end && *p != '\0' && !qjs_xml_ns_sep(*p)) {
            p++;
        }
    }

    if (n >= (SIZE_MAX - src->length - 1) / sizeof(u_char *)) {
        JS_ThrowOutOfMemory(cx);
        return NULL;
    }

    buf = js_malloc(cx, (n + 1) * sizeof(u_char *) + src->length + 1);
    if (buf == NULL) {
        return NULL;
    }

    dst = (u_char *) &buf[n + 1];

    memcpy(dst, src->start, src->length);
    dst[src->length] = '\0';

    out = buf;
    p = dst;

    while (*p != '\0') {
        if (qjs_xml_ns_sep(*p)) {
            *p++ = '\0';
            continue;
        }

        *out++ = p;

        while (*p != '\0' && !qjs_xml_ns_sep(*p)) {
            p++;
        }
    }

    *out = NULL;

    return buf;
}


static int
qjs_xml_node_one_contains(qjs_xml_nset_t *nset, xmlNode *node, xmlNode *parent)
{
    int    in;
    xmlNs  ns;

    if (nset->type == XML_NSET_TREE_NO_COMMENTS
        && node->type == XML_COMMENT_NODE)
    {
        return 0;
    }

    in = 1;

    if (nset->nodes != NULL) {
        if (node->type != XML_NAMESPACE_DECL) {
            in = xmlXPathNodeSetContains(nset->nodes, node);

        } else {

            memcpy(&ns, node, sizeof(ns));

            /* libxml2 workaround, check xpath.c for details */

            if ((parent != NULL) && (parent->type == XML_ATTRIBUTE_NODE)) {
                ns.next = (xmlNs *) parent->parent;

            } else {
                ns.next = (xmlNs *) parent;
            }

            in = xmlXPathNodeSetContains(nset->nodes, (xmlNode *) &ns);
        }
    }

    switch (nset->type) {
    case XML_NSET_TREE:
    case XML_NSET_TREE_NO_COMMENTS:
        if (in != 0) {
            return 1;
        }

        if ((parent != NULL) && (parent->type == XML_ELEMENT_NODE)) {
            return qjs_xml_node_one_contains(nset, parent, parent->parent);
        }

        return 0;

    case XML_NSET_TREE_INVERT:
    default:
        if (in != 0) {
            return 0;
        }

        if ((parent != NULL) && (parent->type == XML_ELEMENT_NODE)) {
            return qjs_xml_node_one_contains(nset, parent, parent->parent);
        }
    }

    return 1;
}


static int
qjs_xml_c14n_visibility_cb(void *user_data, xmlNode *node, xmlNode *parent)
{
    int             status;
    qjs_xml_nset_t  *n, *nset;

    nset = user_data;

    if (nset == NULL) {
        return 1;
    }

    status = 1;

    n = nset;

    do {
        if (status && !qjs_xml_node_one_contains(n, node, parent)) {
            status = 0;
        }

        n = n->next;
    } while (n != nset);

    return status;
}


static int
qjs_xml_buf_write_cb(void *context, const char *buffer, int len)
{
    njs_chb_t  *chain = context;

    njs_chb_append(chain, buffer, len);

    return chain->error ? -1 : len;
}


static qjs_xml_nset_t *
qjs_xml_nset_create(JSContext *cx, xmlDoc *doc, xmlNode *current,
    qjs_xml_nset_type_t type)
{
    xmlNodeSet      *nodes;
    qjs_xml_nset_t  *nset;

    nset = js_mallocz(cx, sizeof(qjs_xml_nset_t));
    if (nset == NULL) {
        JS_ThrowOutOfMemory(cx);
        return NULL;
    }

    nodes = xmlXPathNodeSetCreate(current);
    if (nodes == NULL) {
        js_free(cx, nset);
        JS_ThrowOutOfMemory(cx);
        return NULL;
    }

    nset->doc = doc;
    nset->type = type;
    nset->nodes = nodes;
    nset->next = nset->prev = nset;

    return nset;
}


static qjs_xml_nset_t *
qjs_xml_nset_add(qjs_xml_nset_t *nset, qjs_xml_nset_t *add)
{
    if (nset == NULL) {
        return add;
    }

    add->next = nset;
    add->prev = nset->prev;
    nset->prev->next = add;
    nset->prev = add;

    return nset;
}


static void
qjs_xml_nset_free(JSContext *cx, qjs_xml_nset_t *nset)
{
    if (nset == NULL) {
        return;
    }

    if (nset->nodes != NULL) {
        xmlXPathFreeNodeSet(nset->nodes);
    }

    js_free(cx, nset);
}


static qjs_xml_node_t *
qjs_xml_ns_args(JSContext *cx, JSValueConst this_val, JSValueConst *argv,
    njs_str_t *uri, njs_str_t *local)
{
    size_t          length;
    qjs_xml_node_t  *current;

    current = JS_GetOpaque(this_val, QJS_CORE_CLASS_ID_XML_NODE);
    if (current == NULL) {
        JS_ThrowTypeError(cx, "\"this\" is not a XMLNode object");
        return NULL;
    }

    if (!JS_IsNull(argv[0]) && !JS_IsString(argv[0])) {
        JS_ThrowTypeError(cx, "namespace URI is not a string or null");
        return NULL;
    }

    if (!JS_IsString(argv[1])) {
        JS_ThrowTypeError(cx, "local name is not a string");
        return NULL;
    }

    uri->start = NULL;
    uri->length = 0;

    if (JS_IsString(argv[0])) {
        uri->start = (u_char *) JS_ToCStringLen(cx, &length, argv[0]);
        if (uri->start == NULL) {
            return NULL;
        }

        uri->length = length;
    }

    local->start = (u_char *) JS_ToCStringLen(cx, &length, argv[1]);
    if (local->start == NULL) {
        if (uri->start != NULL) {
            JS_FreeCString(cx, (char *) uri->start);
        }

        return NULL;
    }

    local->length = length;

    return current;
}


static void
qjs_xml_ns_args_free(JSContext *cx, njs_str_t *uri, njs_str_t *local)
{
    if (uri->start != NULL) {
        JS_FreeCString(cx, (char *) uri->start);
    }

    JS_FreeCString(cx, (char *) local->start);
}


/*
 * An empty or null URI matches only names without a namespace, as in
 * DOM getAttributeNS().
 */

static int
qjs_xml_ns_match(const xmlChar *name, xmlNs *ns, njs_str_t *uri,
    njs_str_t *local)
{
    if (local->length != njs_strlen(name)
        || njs_strncmp(local->start, name, local->length) != 0)
    {
        return 0;
    }

    if (ns == NULL || ns->href == NULL) {
        return uri->length == 0;
    }

    return uri->length == njs_strlen(ns->href)
           && njs_strncmp(uri->start, ns->href, uri->length) == 0;
}


static int
qjs_xml_node_is_live(xmlNode *node)
{
    xmlNode  *parent;

    if (node == NULL || node->doc == NULL) {
        return 0;
    }

    for (parent = node->parent; parent != NULL; parent = parent->parent) {
        if (parent == (xmlNode *) node->doc) {
            return 1;
        }
    }

    return 0;
}


static xmlNode *
qjs_xml_list_detach(xmlNode *parent, njs_str_t *name)
{
    xmlNode  *node, *next, *first, *last, *keep_first, *keep_last;

    if (name == NULL) {
        first = parent->children;
        parent->children = NULL;
        parent->last = NULL;

        for (node = first; node != NULL; node = node->next) {
            node->parent = NULL;
        }

        return first;
    }

    first = NULL;
    last = NULL;
    keep_first = NULL;
    keep_last = NULL;

    for (node = parent->children; node != NULL; node = next) {
        next = node->next;

        if (node->type == XML_ELEMENT_NODE
            && name->length == njs_strlen(node->name)
            && njs_strncmp(name->start, node->name, name->length) == 0)
        {
            node->parent = NULL;
            node->prev = last;
            node->next = NULL;

            if (last != NULL) {
                last->next = node;

            } else {
                first = node;
            }

            last = node;

        } else {
            node->parent = parent;
            node->prev = keep_last;
            node->next = NULL;

            if (keep_last != NULL) {
                keep_last->next = node;

            } else {
                keep_first = node;
            }

            keep_last = node;
        }
    }

    parent->children = keep_first;
    parent->last = keep_last;

    return first;
}


static int
qjs_xml_list_retire(JSContext *cx, qjs_xml_doc_t *doc, xmlNode *parent,
    njs_str_t *name)
{
    qjs_xml_retired_t  *retired;

    retired = js_malloc(cx, sizeof(qjs_xml_retired_t));
    if (retired == NULL) {
        JS_ThrowOutOfMemory(cx);
        return -1;
    }

    retired->nodes = qjs_xml_list_detach(parent, name);
    retired->next = doc->retired;
    doc->retired = retired;

    return 1;
}


static void
qjs_xml_list_append(xmlNode *parent, xmlNode *node)
{
    node->parent = parent;
    node->prev = parent->last;
    node->next = NULL;

    if (parent->last != NULL) {
        parent->last->next = node;

    } else {
        parent->children = node;
    }

    parent->last = node;
}


static int
qjs_xml_tree_has_namespaces(xmlNode *node)
{
    xmlAttr  *attr;
    xmlNode  *child;

    switch (node->type) {
    case XML_ELEMENT_NODE:
        break;

    case XML_TEXT_NODE:
    case XML_CDATA_SECTION_NODE:
    case XML_PI_NODE:
    case XML_COMMENT_NODE:
        return 0;

    default:
        return 1;
    }

    if (node->ns != NULL || node->nsDef != NULL) {
        return 1;
    }

    for (attr = node->properties; attr != NULL; attr = attr->next) {
        if (attr->ns != NULL) {
            return 1;
        }
    }

    for (child = node->children; child != NULL; child = child->next) {
        if (qjs_xml_tree_has_namespaces(child)) {
            return 1;
        }
    }

    return 0;
}


static void
qjs_xml_error(JSContext *cx, xmlParserCtxt *ctx, const char *fmt, ...)
{
    u_char          *p, *last;
    va_list         args;
    const xmlError  *err;
    u_char          errstr[NJS_MAX_ERROR_STR];

    last = &errstr[NJS_MAX_ERROR_STR];

    va_start(args, fmt);
    p = njs_vsprintf(errstr, last - 1, fmt, args);
    va_end(args);

    err = xmlCtxtGetLastError(ctx);

    if (err != NULL) {
        p = njs_sprintf(p, last - 1, " (libxml2: \"%*s\" at %d:%d)",
                        njs_strlen(err->message) - 1, err->message, err->line,
                        err->int2);
    }

    JS_ThrowSyntaxError(cx, "%.*s", (int) (p - errstr), errstr);
}


static int
qjs_xml_module_init(JSContext *cx, JSModuleDef *m)
{
    JSValue  proto;

    proto = JS_NewObject(cx);
    if (JS_IsException(proto)) {
        return -1;
    }

    JS_SetPropertyFunctionList(cx, proto, qjs_xml_export,
                               njs_nitems(qjs_xml_export));

    if (JS_SetModuleExport(cx, m, "default", proto) != 0) {
        return -1;
    }

    return JS_SetModuleExportList(cx, m, qjs_xml_export,
                                  njs_nitems(qjs_xml_export));
}


static JSModuleDef *
qjs_xml_init(JSContext *cx, const char *name)
{
    int          rc;
    JSValue      proto;
    JSModuleDef  *m;

    if (!JS_IsRegisteredClass(JS_GetRuntime(cx),
                              QJS_CORE_CLASS_ID_XML_DOC))
    {
        if (JS_NewClass(JS_GetRuntime(cx), QJS_CORE_CLASS_ID_XML_DOC,
                        &qjs_xml_doc_class) < 0)
        {
            return NULL;
        }

        proto = JS_NewObject(cx);
        if (JS_IsException(proto)) {
            return NULL;
        }

        JS_SetPropertyFunctionList(cx, proto, qjs_xml_doc_proto,
                                   njs_nitems(qjs_xml_doc_proto));

        JS_SetClassProto(cx, QJS_CORE_CLASS_ID_XML_DOC, proto);

        if (JS_NewClass(JS_GetRuntime(cx), QJS_CORE_CLASS_ID_XML_NODE,
                        &qjs_xml_node_class) < 0)
        {
            return NULL;
        }

        proto = JS_NewObject(cx);
        if (JS_IsException(proto)) {
            return NULL;
        }

        JS_SetPropertyFunctionList(cx, proto, qjs_xml_node_proto,
                                   njs_nitems(qjs_xml_node_proto));

        JS_SetClassProto(cx, QJS_CORE_CLASS_ID_XML_NODE, proto);

        if (JS_NewClass(JS_GetRuntime(cx), QJS_CORE_CLASS_ID_XML_ATTR,
                        &qjs_xml_attr_class) < 0)
        {
            return NULL;
        }

        proto = JS_NewObject(cx);
        if (JS_IsException(proto)) {
            return NULL;
        }

        JS_SetPropertyFunctionList(cx, proto, qjs_xml_attr_proto,
                                   njs_nitems(qjs_xml_attr_proto));

        JS_SetClassProto(cx, QJS_CORE_CLASS_ID_XML_ATTR, proto);
    }

    m = JS_NewCModule(cx, name, qjs_xml_module_init);
    if (m == NULL) {
        return NULL;
    }

    JS_AddModuleExport(cx, m, "default");
    rc = JS_AddModuleExportList(cx, m, qjs_xml_export,
                                njs_nitems(qjs_xml_export));
    if (rc != 0) {
        return NULL;
    }

    return m;
}

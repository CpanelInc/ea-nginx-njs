/*---
includes: []
flags: []
negative:
  phase: runtime
---*/

Promise.reject(1);

